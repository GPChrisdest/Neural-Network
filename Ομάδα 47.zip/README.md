__Οδηγίες Εγκατάστασης:__

• Χρειάζεται να κάνετε add την Python στο PATH του υπολογιστή
• Να υπάρχει εγκατεστημένη Python 2.7.18, pip, numpy και matplotlib
    (https://www.youtube.com/watch?v=0qwyHdA2_rw&t=98s
    https://www.youtube.com/watch?v=K87M0sMVXZE&t=179s
    https://www.youtube.com/watch?v=EmBntQAnWyc)
• Στο φάκελο code πρέπει να έχετε σίγουρα μέσα το Python Terminal
• Ανοίγετε το terminal και γράφετε την εντολή: execfile(“menu.py”)

__Οδηγίες Λειτουργίας:__

Όταν ξεκινήσει το πρόγραμμα θα σας εμφανιστούν 3 επιλογές:
• Train
• Find hand written number
• Exit

**Train**
Το πρόγραμμα ξεκινάει την εκπαίδευση του νευρωνικού δικτύου και αποθηκεύει τα δεδομένα σε binary αρχεία ώστε να τα φορτώσει μετά

**Find hand written number**
Το πρόγραμμα εμφανίζει μία τυχαία εικόνα από το αρχείο MNIST και εμφανίζονται οι παρακάτω επιλογές:

• Select this photo
    Όπου αυτή η εικόνα εισάγεται στο νευρωνικό δίκτυο για αναγνώριση
• Move to next photo
    Όπου εμφανίζεται νέα τυχαία εικόνα
• Back to main menu
    Επιστροφή στο κυρίως menu

**Exit**
Έξοδος από το πρόγραμμα